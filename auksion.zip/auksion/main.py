# main.py
from typing import List, Optional

from fastapi import FastAPI, HTTPException, Depends, Header
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from database import get_db, AutoPlate, Bid, User  
from schemas import PlateCreate, PlateResponse, BidCreate, BidResponse, UserCreate, UserResponse 
from datetime import datetime
from sqlalchemy import func

app = FastAPI()

API_KEY = "admin123"  # Replace with a secure key


async def get_api_key(x_api_key: str = Header(...)):
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API Key")
    return x_api_key


# --- User Management (Basic) ---
@app.post("/users/", response_model=UserResponse)
async def create_user(user: UserCreate, db: Session = Depends(get_db)):
    db_user = User(username=user.username, email=user.email, is_staff=user.is_staff)
    db_user.set_password(user.password)  
    try:
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        return db_user
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Username or email already exists")


@app.get("/users/{user_id}/", response_model=UserResponse)
async def read_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user


# --- Auto Plate Endpoints ---
@app.post("/plates/", response_model=PlateResponse)
async def create_plate(plate: PlateCreate, db: Session = Depends(get_db), api_key: str = Depends(get_api_key)):
    if plate.deadline <= datetime.now():
        raise HTTPException(status_code=400, detail="Deadline must be in the future")
    db_plate = AutoPlate(
        plate_number=plate.plate_number,
        description=plate.description,
        deadline=plate.deadline,
        is_active=plate.is_active,
    )

    try:
        db.add(db_plate)
        db.commit()
        db.refresh(db_plate)
        return db_plate
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Plate number already exists")


@app.get("/plates/", response_model=List[PlateResponse])
async def read_plates(
        db: Session = Depends(get_db),
        ordering: Optional[str] = None,
        plate_number__contains: Optional[str] = None
):
    query = db.query(AutoPlate).filter(AutoPlate.is_active == True)

    if plate_number__contains:
        query = query.filter(AutoPlate.plate_number.contains(plate_number__contains))

    if ordering:
        if ordering == "deadline":
            query = query.order_by(AutoPlate.deadline)
    plates = query.all()
    return plates


@app.get("/plates/{plate_id}/", response_model=PlateResponse)
async def read_plate(plate_id: int, db: Session = Depends(get_db)):
    plate = db.query(AutoPlate).filter(AutoPlate.id == plate_id).first()
    if plate is None:
        raise HTTPException(status_code=404, detail="Plate not found")

    bids = db.query(Bid).filter(Bid.plate_id == plate_id).all()
    plate.__dict__['bids'] = bids 
    return plate


@app.put("/plates/{plate_id}/", response_model=PlateResponse)
async def update_plate(
        plate_id: int, plate: PlateCreate, db: Session = Depends(get_db), api_key: str = Depends(get_api_key)
):
    db_plate = db.query(AutoPlate).filter(AutoPlate.id == plate_id).first()
    if db_plate is None:
        raise HTTPException(status_code=404, detail="Plate not found")

    db_plate.plate_number = plate.plate_number
    db_plate.description = plate.description
    db_plate.deadline = plate.deadline
    db_plate.is_active = plate.is_active

    try:
        db.commit()
        db.refresh(db_plate)
        return db_plate
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Plate number already exists")


@app.delete("/plates/{plate_id}/", status_code=204)
async def delete_plate(plate_id: int, db: Session = Depends(get_db), api_key: str = Depends(get_api_key)):
    db_plate = db.query(AutoPlate).filter(AutoPlate.id == plate_id).first()
    if db_plate is None:
        raise HTTPException(status_code=404, detail="Plate not found")

    bids = db.query(Bid).filter(Bid.plate_id == plate_id).all()
    if bids:
        raise HTTPException(
            status_code=400, detail="Cannot delete plate with active bids"
        )  

    db.delete(db_plate)
    db.commit()
    return


# --- Bid Endpoints ---

@app.post("/bids/", response_model=BidResponse)
async def create_bid(bid: BidCreate, db: Session = Depends(get_db), api_key: str = Depends(get_api_key)):
    user = db.query(User).first()
    if not user:
        user = User(username="default_user", email="default@example.com")
        db.add(user)
        db.commit()

    plate = db.query(AutoPlate).filter(AutoPlate.id == bid.plate_id).first()
    if not plate:
        raise HTTPException(status_code=404, detail="Plate not found")

    if not plate.is_active or plate.deadline <= datetime.now():
        raise HTTPException(status_code=400, detail="Bidding is closed")  

    existing_bid = db.query(Bid).filter(Bid.user_id == user.id, Bid.plate_id == bid.plate_id).first()
    if existing_bid:
        raise HTTPException(status_code=400, detail="You already have a bid on this plate")  

    highest_bid = db.query(func.max(Bid.amount)).filter(Bid.plate_id == bid.plate_id).scalar()
    if highest_bid is not None and bid.amount <= highest_bid:
        raise HTTPException(
            status_code=400, detail="Bid must exceed current highest bid"
        ) 
    if bid.amount <= 0:
        raise HTTPException(
            status_code=400, detail="Bid amount must be positive"
        )  

    db_bid = Bid(amount=bid.amount, user_id=user.id, plate_id=bid.plate_id)

    db.add(db_bid)
    db.commit()
    db.refresh(db_bid)
    return db_bid


@app.get("/bids/", response_model=List[BidResponse])
async def read_bids(db: Session = Depends(get_db), api_key: str = Depends(get_api_key)):
    user = db.query(User).first()
    if not user:
        user = User(username="default_user", email="default@example.com")
        db.add(user)
        db.commit()
    bids = db.query(Bid).filter(Bid.user_id == user.id).all()
    return bids


@app.get("/bids/{bid_id}/", response_model=BidResponse)
async def read_bid(bid_id: int, db: Session = Depends(get_db), api_key: str = Depends(get_api_key)):
    user = db.query(User).first()
    if not user:
        user = User(username="default_user", email="default@example.com")
        db.add(user)
        db.commit()

    bid = db.query(Bid).filter(Bid.id == bid_id, Bid.user_id == user.id).first()
    if not bid:
        raise HTTPException(status_code=404, detail="Bid not found")

    return bid


@app.put("/bids/{bid_id}/", response_model=BidResponse)
async def update_bid(
        bid_id: int, bid: BidCreate, db: Session = Depends(get_db), api_key: str = Depends(get_api_key)
):
    user = db.query(User).first()
    if not user:
        user = User(username="default_user", email="default@example.com")
        db.add(user)
        db.commit()
    db_bid = db.query(Bid).filter(Bid.id == bid_id, Bid.user_id == user.id).first()
    if not db_bid:
        raise HTTPException(status_code=404, detail="Bid not found")

    plate = db.query(AutoPlate).filter(AutoPlate.id == bid.plate_id).first()
    if not plate:
        raise HTTPException(status_code=404, detail="Plate not found")
    if plate.deadline <= datetime.now():
        raise HTTPException(status_code=403, detail="Bidding period has ended") 

    highest_bid = db.query(func.max(Bid.amount)).filter(Bid.plate_id == bid.plate_id).scalar()
    if highest_bid is not None and bid.amount <= highest_bid:
        raise HTTPException(
            status_code=400, detail="Bid must exceed current highest bid"
        )  
    db_bid.amount = bid.amount

    db.commit()
    db.refresh(db_bid)
    return db_bid


@app.delete("/bids/{bid_id}/", status_code=204)
async def delete_bid(bid_id: int, db: Session = Depends(get_db), api_key: str = Depends(get_api_key)):
    user = db.query(User).first()
    if not user:
        user = User(username="default_user", email="default@example.com")
        db.add(user)
        db.commit()
    db_bid = db.query(Bid).filter(Bid.id == bid_id, Bid.user_id == user.id).first()
    if not db_bid:
        raise HTTPException(status_code=404, detail="Bid not found")
    plate = db.query(AutoPlate).filter(AutoPlate.id == db_bid.plate_id).first()
    if not plate:
        raise HTTPException(status_code=404, detail="Plate not found")
    if plate.deadline <= datetime.now():
        raise HTTPException(status_code=403, detail="Bidding period has ended")  

    db.delete(db_bid)
    db.commit()
    return




# #
# # from scapy.all import ARP, Ether, srp
# # import sys
# # import requests
# #
# # # Tarmoq interfeysini aniqlash (masalan: "eth0" yoki "wlan0")
# # interface = "wlo1" # O'zingizning interfeysingizga moslashtiring
# #
# # # Skanalayotgan tarmoq diapazoni (masalan, '192.168.1.0/24')
# # target_ip = "10.30.0.0/20" # O'zingizning tarmoq diapazoningizga moslashtiring
# #
# # def get_vendor(mac):
# #     """MAC manzil bo'yicha qurilma ishlab chiqaruvchisini aniqlash"""
# #     url = f"https://api.macvendors.com/{mac}"
# #     try:
# #         response = requests.get(url, timeout=5)
# #         if response.status_code == 200:
# #             return response.text
# #         else:
# #             return "Noma'lum vendor"
# #     except:
# #         return "Internet ulanishi yo'q"
# #
# # from scapy.all import ARP, Ether, srp
# #
# # def scan_network(ip):
# #     try:
# #         # ARP request to find devices on the network
# #         arp_request = ARP(pdst=ip)
# #         ether = Ether(dst="ff:ff:ff:ff:ff:ff")
# #         packet = ether / arp_request
# #
# #         result = srp(packet, timeout=3, verbose=False)[0]
# #
# #         devices = []
# #         for sent, received in result:
# #             vendor = get_vendor(received.hwsrc)  # Get vendor details
# #             devices.append({'ip': received.psrc, 'mac': received.hwsrc, 'vendor': vendor})
# #
# #         return devices
# #     except Exception as err:
# #         print(f"Error: {err}")
# #         return []
# #
# # def save_to_file(devices):
# #     # Save to file
# #     with open("mac_addresses.txt", "w") as file:
# #         file.write("IP Address\tMAC Address\tVendor\n")
# #         file.write("-" * 60 + "\n")
# #         for device in devices:
# #             file.write(f"{device['ip']}\t{device['mac']}\t{device['vendor']}\n")
# #
# # def main():
# #     print("Tarmoqn skanlash boshlandi...")
# #     devices = scan_network(target_ip)
# #     if devices:
# #         print(f"Topilgan qurilmalar soni: {len(devices)}")
# #         print("\nIP Address\t\tMAC address")
# #         print(f"Topilgan qurilmalar soni: {len(devices)}")
# #         save_to_file(devices)
# #         print("Skanlash tugallandi, natijalar faylga saqlandi.")
# #     else:
# #         print("Hech qanday qurilma topilmadi.")
# #
# # if __name__ == "__main__":
# #     main()
# from fastapi import FastAPI, Depends, HTTPException, Query
# from pydantic import BaseModel
# from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, func
# from sqlalchemy.orm import Session, relationship, declarative_base
# from sqlalchemy.exc import IntegrityError
# from sqlalchemy.future import select
# from sqlalchemy.orm import sessionmaker
# from datetime import datetime, timedelta
# from passlib.context import CryptContext
# from typing import List, Optional
# from fastapi.security.api_key import APIKeyHeader

# DATABASE_URL = "sqlite:///./test.db"
# Base = declarative_base()
# SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=None)  # Bind your engine here
# app = FastAPI()

# pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
# api_key_header = APIKeyHeader(name="X-API-KEY", auto_error=False)

# # Dependency for database session
# def get_db():
#     db = SessionLocal()
#     try:
#         yield db
#     finally:
#         db.close()

# # User Model
# class User(Base):
#     __tablename__ = "users"
#     id = Column(Integer, primary_key=True, index=True)
#     username = Column(String, unique=True, index=True)
#     password = Column(String)
#     api_key = Column(String, unique=True, index=True)
#     is_staff = Column(Boolean, default=False)

#     def verify_password(self, password: str) -> bool:
#         return pwd_context.verify(password, self.password)

#     def set_password(self, password: str):
#         self.password = pwd_context.hash(password)

# # Auto Plate Model
# class AutoPlate(Base):
#     __tablename__ = "plates"
#     id = Column(Integer, primary_key=True, index=True)
#     plate_number = Column(String, unique=True, index=True)
#     description = Column(String)
#     deadline = Column(DateTime)
#     is_active = Column(Boolean, default=True)

# # Bid Model
# class Bid(Base):
#     __tablename__ = "bids"
#     id = Column(Integer, primary_key=True, index=True)
#     amount = Column(Integer)
#     user_id = Column(Integer, ForeignKey("users.id"))
#     plate_id = Column(Integer, ForeignKey("plates.id"))

#     user = relationship("User")
#     plate = relationship("AutoPlate")

# # Pydantic Schemas
# class UserCreate(BaseModel):
#     username: str
#     password: str
#     is_staff: bool = False

# class PlateCreate(BaseModel):
#     plate_number: str
#     description: str
#     deadline: datetime
#     is_active: bool = True

# class BidCreate(BaseModel):
#     plate_id: int
#     amount: int

# class PlateResponse(PlateCreate):
#     id: int

# class BidResponse(BaseModel):
#     id: int
#     amount: int
#     user_id: int
#     plate_id: int

# # Authentication function
# def get_api_key(api_key: str = Depends(api_key_header), db: Session = Depends(get_db)):
#     if not api_key:
#         raise HTTPException(status_code=403, detail="API key missing")

#     user = db.query(User).filter(User.api_key == api_key).first()
#     if not user:
#         raise HTTPException(status_code=401, detail="Invalid API key")
    
#     return user

# # Create a new user (Register)
# @app.post("/users/", response_model=dict)
# async def create_user(user: UserCreate, db: Session = Depends(get_db)):
#     db_user = User(username=user.username)
#     db_user.set_password(user.password)
    
#     try:
#         db.add(db_user)
#         db.commit()
#         db.refresh(db_user)
#         return {"message": "User created successfully", "api_key": db_user.api_key}
#     except IntegrityError:
#         db.rollback()
#         raise HTTPException(status_code=400, detail="Username already taken")

# # Create a new auto plate (Admins only)
# @app.post("/plates/", response_model=PlateResponse)
# async def create_plate(
#     plate: PlateCreate, 
#     db: Session = Depends(get_db), 
#     user: User = Depends(get_api_key)
# ):
#     if not user.is_staff:
#         raise HTTPException(status_code=403, detail="Only admins can create plates")

#     if plate.deadline <= datetime.now():
#         raise HTTPException(status_code=400, detail="Deadline must be in the future")

#     db_plate = AutoPlate(
#         plate_number=plate.plate_number,
#         description=plate.description,
#         deadline=plate.deadline,
#         is_active=plate.is_active,
#     )

#     try:
#         db.add(db_plate)
#         db.commit()
#         db.refresh(db_plate)
#         return db_plate
#     except IntegrityError:
#         db.rollback()
#         raise HTTPException(status_code=400, detail="Plate number already exists")

# # Place a bid (Users only)
# @app.post("/bids/", response_model=BidResponse)
# async def create_bid(
#     bid: BidCreate, 
#     db: Session = Depends(get_db), 
#     user: User = Depends(get_api_key)
# ):
#     plate = db.query(AutoPlate).filter(AutoPlate.id == bid.plate_id).first()
#     if not plate:
#         raise HTTPException(status_code=404, detail="Plate not found")

#     if not plate.is_active or plate.deadline <= datetime.now():
#         raise HTTPException(status_code=400, detail="Bidding is closed")

#     highest_bid = db.query(func.max(Bid.amount)).filter(Bid.plate_id == bid.plate_id).scalar()
#     if highest_bid is not None and bid.amount <= highest_bid:
#         raise HTTPException(status_code=400, detail="Bid must exceed current highest bid")

#     db_bid = Bid(amount=bid.amount, user_id=user.id, plate_id=bid.plate_id)

#     db.add(db_bid)
#     db.commit()
#     db.refresh(db_bid)
#     return db_bid

# # Get all auto plates (with filtering)
# @app.get("/plates/", response_model=List[PlateResponse])
# async def read_plates(
#     db: Session = Depends(get_db),
#     plate_number: Optional[str] = Query(None),
#     is_active: Optional[bool] = Query(None),
#     ordering: Optional[str] = Query(None)
# ):
#     query = db.query(AutoPlate)
    
#     if plate_number:
#         query = query.filter(AutoPlate.plate_number.contains(plate_number))
#     if is_active is not None:
#         query = query.filter(AutoPlate.is_active == is_active)

#     if ordering:
#         if ordering == "desc":
#             query = query.order_by(AutoPlate.id.desc())
#         else:
#             query = query.order_by(AutoPlate.id.asc())

#     return query.all()

# # Get all bids for a plate
# @app.get("/plates/{plate_id}/bids/", response_model=List[BidResponse])
# async def read_bids_for_plate(plate_id: int, db: Session = Depends(get_db)):
#     plate = db.query(AutoPlate).filter(AutoPlate.id == plate_id).first()
#     if not plate:
#         raise HTTPException(status_code=404, detail="Plate not found")

#     return db.query(Bid).filter(Bid.plate_id == plate_id).all()

# # Get highest bid for a plate
# @app.get("/plates/{plate_id}/highest_bid/", response_model=BidResponse)
# async def get_highest_bid(plate_id: int, db: Session = Depends(get_db)):
#     highest_bid = db.query(Bid).filter(Bid.plate_id == plate_id).order_by(Bid.amount.desc()).first()
#     if not highest_bid:
#         raise HTTPException(status_code=404, detail="No bids found for this plate")

#     return highest_bid
# import uvicorn

# if __name__ == "__main__":
#     uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
