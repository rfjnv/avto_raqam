# database.py
from sqlalchemy import create_engine, Column, Integer, Boolean, DateTime, String, Numeric, ForeignKey, Date
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import expression
from sqlalchemy.orm import declarative_base
from sqlalchemy import Identity


connect_string = 'sqlite:///auksion.db'
connect_args = {'check_same_thread': False}
engine = create_engine(connect_string, connect_args=connect_args)
Base = declarative_base()
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class AutoPlate(Base):
    __tablename__ = 'autoplate'
    id = Column(Integer, primary_key=True, autoincrement=True)
    plate_number = Column(String, nullable=False, unique=True)
    description = Column(String, nullable=True)
    deadline = Column(Date, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    bids = relationship("Bid", back_populates="plate")


class Bid(Base):
    __tablename__ = 'bid'
    id = Column(Integer, primary_key=True, autoincrement=True)
    amount = Column(Numeric(10, 2), nullable=False)
    user_id = Column(Integer, ForeignKey('user.id'))
    plate_id = Column(Integer, ForeignKey('autoplate.id'))
    created_at = Column(DateTime, default=DateTime)
    user = relationship("User", back_populates="bids")
    plate = relationship("AutoPlate", back_populates="bids")


class User(Base):
    __tablename__ = 'user'
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String, unique=True, nullable=False)
    email = Column(String, unique=True, nullable=False)
    password = Column(String, nullable=False)
    is_staff = Column(Boolean, default=False)
    bids = relationship("Bid", back_populates="user")

    def set_password(self, password):
        # In a real application, use a proper password hashing library!
        self.password = password  # This is INSECURE!  Use bcrypt or similar.


Base.metadata.create_all(engine)