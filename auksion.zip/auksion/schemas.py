# schemas.py
from datetime import datetime
from pydantic import BaseModel


class PlateResponse(BaseModel):
    id: int | None = None
    plate_number: str
    description: str | None = None
    deadline: datetime
    is_active: bool = True

    class Config:
        orm_mode = True


class PlateCreate(BaseModel):
    plate_number: str
    description: str | None = None
    deadline: datetime
    is_active: bool = True


class BidResponse(BaseModel):
    id: int
    amount: float
    plate_id: int
    user_id: int
    created_at: datetime

    class Config:
        orm_mode = True


class BidCreate(BaseModel):
    amount: float
    plate_id: int


class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    is_staff: bool

    class Config:
        orm_mode = True


class UserCreate(BaseModel):
    username: str
    email: str
    password: str
    is_staff: bool = False